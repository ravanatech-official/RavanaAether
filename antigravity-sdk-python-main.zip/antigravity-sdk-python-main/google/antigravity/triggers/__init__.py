# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Trigger system for the Google Antigravity SDK."""

from google.antigravity.triggers.helpers import every
from google.antigravity.triggers.helpers import on_file_change
from google.antigravity.triggers.triggers import FileChange
from google.antigravity.triggers.triggers import FileChangeKind
from google.antigravity.triggers.triggers import Trigger
from google.antigravity.triggers.triggers import trigger
from google.antigravity.triggers.triggers import TriggerContext

__all__ = [
    "every",
    "on_file_change",
    "FileChange",
    "FileChangeKind",
    "Trigger",
    "TriggerContext",
    "trigger",
]
